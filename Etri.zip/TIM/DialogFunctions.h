#pragma once

extern LRESULT CALLBACK DialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
extern LRESULT CALLBACK TestOptionProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
extern LRESULT CALLBACK PortOptionProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
extern LRESULT CALLBACK InformationProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
extern LRESULT CALLBACK LoraInformation(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);